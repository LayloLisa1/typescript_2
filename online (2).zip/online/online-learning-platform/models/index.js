const Sequelize = require('sequelize');
const UserModel = require('./user');
const CourseModel = require('./course');
const ModuleModel = require('./module');
const LessonModel = require('./lesson');
const EnrollmentModel = require('./enrollment');
const AssignmentModel = require('./assignment');
const SubmissionModel = require('./submission');
const sequelize = new Sequelize(/* your database connection details */);

const User = UserModel(sequelize, Sequelize);
const Course = CourseModel(sequelize, Sequelize);
const Module = ModuleModel(sequelize, Sequelize);
const Lesson = LessonModel(sequelize, Sequelize);
const Enrollment = EnrollmentModel(sequelize, Sequelize);
const Assignment = AssignmentModel(sequelize, Sequelize);
const Submission = SubmissionModel(sequelize, Sequelize);

module.exports = {
  sequelize,
  User,
  Course,
  Module,
  Lesson,
  Enrollment,
  Assignment,
  Submission
};
